package correccion;

import java.util.Arrays;
import correccion.Materia;

public class Sistema extends Materia{
	
	private Materia[] materias;
	
	public Materia[] getMaterias(){
		return materias;
	}
	
	public void setMaterias(Materia[] materias){
		this.materias = materias;
	}
	
	public String materiasPorProfesor(String idProfesor ){
		String materiasDelProfe=null;
		Profesor[] p=getProfesores_();
		for(Materia m: materias){
			/*if((m.getProfesores_())==Integer.parseInt(idProfesor)){
				materiasDelProfe=materiasDelProfe+","+m.getNombreMat_();
			}	
			//m.getProfesores_();*/
		}
		return materiasDelProfe;	
	}
	
	public Profesor[] buscarProfesores(String idProfesor){
		//Profesor[] prof = null;
		for (Profesor p:getProfesores_()){
			if(p.getIdProf()==Integer.parseInt(idProfesor)){
				
				return getProfesores_();
				
			}
		}
		return null;
		
	}
	
	@Override
	public String toString() {
		return "Sistema [materias=" + Arrays.toString(materias) + "]";
	}
	
	public Sistema(int codigo_, String nombreMat_, int nHoras_, Profesor[] profesores_, Alumno[] alumnos_) {
		super(codigo_, nombreMat_, nHoras_, profesores_, alumnos_);
		// TODO Auto-generated constructor stub
	}

	

}
