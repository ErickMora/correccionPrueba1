package correccion;

import java.util.Arrays;

public class Materia {
	private int codigo_;
	private String nombreMat_;
	private int nHoras_;
	private Profesor[] profesores_;
	private Alumno[] alumnos_;

	public int getCodigo_() {
		return codigo_;
	}

	public void setCodigo_(int codigo_) {
		this.codigo_ = codigo_;
	}

	public String getNombreMat_() {
		return nombreMat_;
	}

	public void setNombreMat_(String nombreMat_) {
		this.nombreMat_ = nombreMat_;
	}

	public int getnHoras_() {
		return nHoras_;
	}

	public void setnHoras_(int nHoras_) {
		this.nHoras_ = nHoras_;
	}

	public Profesor[] getProfesores_() {
		return profesores_;
	}

	public void setProfesores_(Profesor[] profesores_) {
		this.profesores_ = profesores_;
	}

	public Alumno[] getAlumnos_() {
		return alumnos_;
	}

	public void setAlumnos_(Alumno[] alumnos_) {
		this.alumnos_ = alumnos_;
	}

	/*public Materia() {
		
		this.codigo_ = 0;
		this.nombreMat_ = "Materia 1";
		this.nHoras_ = 2;
		this.profesores_ new Profesor[]= {new Profesor(), new Profesor()};
		this.alumnos_ new Alumno[]= {new Alumno(), new Alumno()};
	}*/


	public Materia(int codigo_, String nombreMat_, int nHoras_,
			Profesor[] profesores_, Alumno[] alumnos_) {
		super();
		this.codigo_ = codigo_;
		this.nombreMat_ = nombreMat_;
		this.nHoras_ = nHoras_;
		this.profesores_ = profesores_;
		this.alumnos_ = alumnos_;
	}

	@Override
	public String toString() {
		return "Materia [codigo=" + codigo_ + ", nombreMat=" + nombreMat_
				+ ", nHoras=" + nHoras_ + ",\n"+"profesores=" 
				+ Arrays.toString(profesores_) +",\n"+ "alumnos="
				+ Arrays.toString(alumnos_) + "]";
	}
	
	

}
