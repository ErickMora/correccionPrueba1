package correccion;

public class Profesor extends Persona{
	private int idProf;

	public int getIdProf() {
		return idProf;
	}

	public void setIdProf(int idProf) {
		this.idProf = idProf;
	}

	@Override
	public String toString() {
		return "Profesor: " + this.getNombre1() +","+ this.getNombre2() +","+ this.getApellido1() +","+ this.getApellido2();
	}
}
