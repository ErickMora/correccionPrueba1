package correccion;

import java.io.IOException;
import correccion.Sistema;

public class Aplicacion {

	public static void main(String args[]) throws IOException
	{
		Sistema sis = new Sistema(0, null, 0, null, null);
		//sis.materiasPorProfesor(null);
		
		Alumno a1=new Alumno(15);
		Alumno a2=new Alumno(15);
		Alumno a3=new Alumno(15);
		Alumno a4=new Alumno(15);
		Alumno a5=new Alumno(15);
		Alumno a6=new Alumno(15);
		Alumno a7=new Alumno(15);
		Alumno a8=new Alumno(15);
		Alumno a9=new Alumno(15);
		Alumno a10=new Alumno(15);
		
		Profesor p1=new Profesor();
		Profesor p2=new Profesor();
		Profesor p3=new Profesor();
		Profesor p4=new Profesor();
		Profesor p5=new Profesor();
		Profesor p6=new Profesor();
		Profesor p7=new Profesor();
		Profesor p8=new Profesor();
		Profesor p9=new Profesor();
		Profesor p10=new Profesor();
		
		Materia m1=new Materia(0, null, 0, null, null);
		Materia m2=new Materia(0, null, 0, null, null);
		Materia m3=new Materia(0, null, 0, null, null);
		Materia m4=new Materia(0, null, 0, null, null);
		Materia m5=new Materia(0, null, 0, null, null);
		Materia m6=new Materia(0, null, 0, null, null);
		Materia m7=new Materia(0, null, 0, null, null);
		Materia m8=new Materia(0, null, 0, null, null);
		Materia m9=new Materia(0, null, 0, null, null);
		Materia m10=new Materia(0, null, 0, null, null);
		
		Alumno[] grupo1={a1,a2,a8,a7,a9,a5};
		Alumno[] grupo2={a2,a3,a9,a8,a10,a7,a4};
		Alumno[] grupo3={a3,a4,a10,a9,a1,a2,a8,a6};
		Alumno[] grupo4={a4,a5,a1,a10,a2,a3,a8,a6,a9};
		Alumno[] grupo5={a5,a6,a2,a1,a3,a4,a7,a8,a9,a10};
		Alumno[] grupo6={a6,a1,a3,a2,a4,a10,a9,a8,a5};
		Alumno[] grupo7={a7,a8,a4,a3,a5,a1,a2,a6,a9,a10};
		Alumno[] grupo8={a8,a9,a5,a4,a6,a3,a10,a2};
		Alumno[] grupo9={a9,a10,a6,a5,a7,a1,a3};
		Alumno[] grupo10={a10,a1,a7,a6,a8,a9};
		
		Profesor[] mat1={p1,p10,p5};
		Profesor[] mat2={p2,p9,p4,p1};
		Profesor[] mat3={p3};
		Profesor[] mat4={p4,p7};
		Profesor[] mat5={p5,p6};
		Profesor[] mat6={p6,p5,p10};
		Profesor[] mat7={p7,p4,p2};
		Profesor[] mat8={p8};
		Profesor[] mat9={p9};
		Profesor[] mat10={p10,p1};
				
		a1.setNombre1("Juan");
		a1.setApellido1("Perez");
		a2.setNombre1("Mario");
		a2.setApellido1("Lala");
		a3.setNombre1("Santiago");
		a3.setApellido1("Sarmiento");
		a4.setNombre1("Maria");
		a4.setApellido1("Vera");
		a5.setNombre1("Bel�n");
		a5.setApellido1("Guam�n");
		a6.setNombre1("Fernanda");
		a6.setApellido1("Garc�a");
		a7.setNombre1("Ra�l");
		a7.setApellido1("Segovia");
		a8.setNombre1("Karen");
		a8.setApellido1("Altamirano");
		a9.setNombre1("Patricia");
		a9.setApellido1("Uvidia");
		a10.setNombre1("William");
		a10.setApellido1("Smith");
		a1.setNombre2("Kevin");
		a1.setApellido2("Prado");
		a2.setNombre2("Brandon");
		a2.setApellido2("Lema");
		a3.setNombre2("Tom");
		a3.setApellido2("Sawyer");
		a4.setNombre2("Bel�n");
		a4.setApellido2("Mera");
		a5.setNombre2("Nicole");
		a5.setApellido2("Godoy");
		a6.setNombre2("Britanny");
		a6.setApellido2("Maruja");
		a7.setNombre2("Jhonny");
		a7.setApellido2("Altaria");
		a8.setNombre2("Andrea");
		a8.setApellido2("Albuja");
		a9.setNombre2("Jenny");
		a9.setApellido2("Zurita");
		a10.setNombre2("Tyson");
		a10.setApellido2("Churchill");
		
		p1.setIdProf(1);
		p2.setIdProf(2);
		p3.setIdProf(3);
		p4.setIdProf(4);
		p5.setIdProf(5);
		p6.setIdProf(6);
		p7.setIdProf(7);
		p8.setIdProf(8);
		p9.setIdProf(9);
		p10.setIdProf(10);
		p1.setNombre1("Luis");
		p1.setApellido1("Sandoval");
		p2.setNombre1("M�nica");
		p2.setApellido1("Padilla");
		p3.setNombre1("Daniel");
		p3.setApellido1("Zurita");
		p4.setNombre1("Ra�l");
		p4.setApellido1("Carter");
		p5.setNombre1("Carlos");
		p5.setApellido1("Naranjo");
		p6.setNombre1("Galo");
		p6.setApellido1("Fuertes");
		p7.setNombre1("Eduardo");
		p7.setApellido1("Naranjales");
		p8.setNombre1("Cho");
		p8.setApellido1("Chang");
		p9.setNombre1("Tania");
		p9.setApellido1("S�nchez");
		p10.setNombre1("Carlos");
		p10.setApellido1("P�rez");
		p1.setNombre2("Alan");
		p1.setApellido2("Fuentes");
		p2.setNombre2("�rsula");
		p2.setApellido2("Impia");
		p3.setNombre2("Lem");
		p3.setApellido2("Wigg");
		p4.setNombre2("Pa�l");
		p4.setApellido2("Pozo");
		p5.setNombre2("Gary");
		p5.setApellido2("Manzano");
		p6.setNombre2("Tobias");
		p6.setApellido2("Fontana");
		p7.setNombre2("Gerardo");
		p7.setApellido2("Manzanares");
		p8.setNombre2("Eu");
		p8.setApellido2("Lee");
		p9.setNombre2("Serena");
		p9.setApellido2("Hudson");
		p10.setNombre2("Max");
		p10.setApellido2("Power");
		
		m1.setCodigo_(1);
		m2.setCodigo_(2);
		m3.setCodigo_(3);
		m4.setCodigo_(4);
		m5.setCodigo_(5);
		m6.setCodigo_(6);
		m7.setCodigo_(7);
		m8.setCodigo_(8);
		m9.setCodigo_(9);
		m10.setCodigo_(10);
		
		m1.setNombreMat_("Matem�ticas");
		m2.setNombreMat_("F�sica");
		m3.setNombreMat_("Qu�mica");
		m4.setNombreMat_("Ingl�s");
		m5.setNombreMat_("Literatura");
		m6.setNombreMat_("C�lculo");
		m7.setNombreMat_("Programaci�n");
		m8.setNombreMat_("Franc�s");
		m9.setNombreMat_("Biolog�a");
		m10.setNombreMat_("Sociales");
		
		m1.setnHoras_(5);
		m2.setnHoras_(4);
		m3.setnHoras_(4);
		m4.setnHoras_(5);
		m5.setnHoras_(4);
		m6.setnHoras_(6);
		m7.setnHoras_(6);
		m8.setnHoras_(5);
		m9.setnHoras_(4);
		m10.setnHoras_(4);
		
		m1.setAlumnos_(grupo5);
		m2.setAlumnos_(grupo1);
		m3.setAlumnos_(grupo3);
		m4.setAlumnos_(grupo10);
		m5.setAlumnos_(grupo7);
		m6.setAlumnos_(grupo2);
		m7.setAlumnos_(grupo8);
		m8.setAlumnos_(grupo9);
		m9.setAlumnos_(grupo6);
		m10.setAlumnos_(grupo4);
		
		m1.setProfesores_(mat2);
		m2.setProfesores_(mat1);
		m3.setProfesores_(mat3);
		m4.setProfesores_(mat10);
		m5.setProfesores_(mat8);
		m6.setProfesores_(mat9);
		m7.setProfesores_(mat5);
		m8.setProfesores_(mat7);
		m9.setProfesores_(mat6);
		m10.setProfesores_(mat4);
	
		//System.out.println(a1.toString());
		
		//System.out.println(sis.buscarProfesores(String.valueOf(p1.getIdProf())));
		//System.out.println(sis.buscarProfesores(String.valueOf(p2.getIdProf())).toString());
		//System.out.println(sis.materiasPorProfesor(String.valueOf(p3.getIdProf())));
	/*	sis.buscarProfesores(String.valueOf(p4.getIdProf()));
		sis.buscarProfesores(String.valueOf(p5.getIdProf()));
		sis.buscarProfesores(String.valueOf(p6.getIdProf()));
		sis.buscarProfesores(String.valueOf(p7.getIdProf()));
		sis.buscarProfesores(String.valueOf(p8.getIdProf()));
		sis.buscarProfesores(String.valueOf(p9.getIdProf()));
		sis.buscarProfesores(String.valueOf(p10.getIdProf()));*/
		
		System.out.println("Materias de los Profesores: ");
		System.out.println(p1.toString()+"\n");
		System.out.println(p2.toString()+"\n");
		System.out.println(p3.toString()+"\n");
		System.out.println(p4.toString()+"\n");
		System.out.println(p5.toString()+"\n");
		System.out.println(p6.toString()+"\n");
		System.out.println(p7.toString()+"\n");
		System.out.println(p8.toString()+"\n");
		System.out.println(p9.toString()+"\n");
		System.out.println(p10.toString()+"\n");
		
		System.out.println("\n\nMaterias de los Alumnos: ");
		System.out.println(a1.toString()+"\n");
		System.out.println(a2.toString()+"\n");
		System.out.println(a3.toString()+"\n");
		System.out.println(a4.toString()+"\n");
		System.out.println(a5.toString()+"\n");
		System.out.println(a6.toString()+"\n");
		System.out.println(a7.toString()+"\n");
		System.out.println(a8.toString()+"\n");
		System.out.println(a9.toString()+"\n");
		System.out.println(a10.toString()+"\n");
		
		System.out.println("\n\nAlumnos y profesores de una materia: ");
		System.out.println(m1.toString()+"\n");
		System.out.println(m2.toString()+"\n");
		System.out.println(m3.toString()+"\n");
		System.out.println(m4.toString()+"\n");
		System.out.println(m5.toString()+"\n");
		System.out.println(m6.toString()+"\n");
		System.out.println(m7.toString()+"\n");
		System.out.println(m8.toString()+"\n");
		System.out.println(m9.toString()+"\n");
		System.out.println(m10.toString()+"\n");
		
	}
}
