package correccion;

public class Alumno extends Persona{
	private int edad;

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public Alumno() {
		this.edad = 0;
		
	}
	
	public Alumno(int edad) {
		this.edad = edad;
		
	}
	
	public String getnombre1(){
		return super.getNombre1();
	}

	@Override
	public String toString() {
		return "Alumno: " + this.getNombre1() +","+ this.getNombre2() +","+ this.getApellido1() +","+ this.getApellido2() +","+ this.getEdad();
	}
	

	

}
